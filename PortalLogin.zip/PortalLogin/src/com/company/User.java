package com.company;

public class User {
    public static String password = "7178";
}
