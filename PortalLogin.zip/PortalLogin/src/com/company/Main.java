package com.company;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class Main {

    public static void main(String[] args) throws InterruptedException, IOException{

        System.setProperty("webdriver.gecko.driver", "C:\\Gecko\\geckodriver.exe");
        WebDriver driver= new FirefoxDriver();
        driver.get("http://portal.aait.edu.et");
        Thread.sleep(5000);
        driver.findElement(By.name("UserName")).sendKeys("ATR/7178/09");
        driver.findElement(By.name("Password")).sendKeys(User.password);
        driver.findElement(By.tagName("form")).findElement(By.tagName("button")).click();

        Thread.sleep(5000);
        driver.get("http://portal.aait.edu.et/Grade/GradeReport");

        WebElement gradeReports = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[1]"));

        File document = new File("./GradeReport.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(document));
        writer.write(gradeReports.getText());

        System.out.println(gradeReports.getText());

        System.out.println("Successfully opened the portal login page");


        driver.quit();

    }
}
